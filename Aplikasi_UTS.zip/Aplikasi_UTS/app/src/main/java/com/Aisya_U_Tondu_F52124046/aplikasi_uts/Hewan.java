package com.Aisya_U_Tondu_F52124046.aplikasi_uts;

public class Hewan {
    private String nama;
    private String namaLatin;
    private String kategori;
    private String deskripsi;
    private int fotoResId;

    public Hewan(String nama, String namaLatin, String kategori, String deskripsi, int fotoResId) {
        this.nama = nama;
        this.namaLatin = namaLatin;
        this.kategori = kategori;
        this.deskripsi = deskripsi;
        this.fotoResId = fotoResId;
    }

    public String getNama() { return nama; }
    public String getNamaLatin() { return namaLatin; }
    public String getKategori() { return kategori; }
    public String getDeskripsi() { return deskripsi; }
    public int getFotoResId() { return fotoResId; }
}