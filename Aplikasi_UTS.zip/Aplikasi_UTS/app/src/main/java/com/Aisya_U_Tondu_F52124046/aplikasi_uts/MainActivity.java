package com.Aisya_U_Tondu_F52124046.aplikasi_uts;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listViewHewan;
    private SearchView searchViewHewan;
    private HewanAdapter adapter;
    private List<Hewan> listHewan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewHewan = findViewById(R.id.listview_hewan);
        searchViewHewan = findViewById(R.id.search_view_hewan);

        listHewan = new ArrayList<>();

        listHewan.add(new Hewan(
                "Persia",
                "Felis catus",
                "Longhair / Bulu Panjang",
                "Berbulu panjang dan tebal, wajah cenderung pipih/pesek, serta bertubuh gempal dengan karakter yang tenang dan manja.",
                R.drawable.persia
        ));

        listHewan.add(new Hewan(
                "Maine Coon",
                "Felis catus",
                "Large Breed / Ras Besar",
                "Salah satu ras kucing terbesar di dunia, memiliki bulu lebat tahan air, telinga berumbai seperti lynx, dan ekor yang panjang mengembang.",
                R.drawable.mainecoon
        ));

        listHewan.add(new Hewan(
                "Siamese (Siam)",
                "Felis catus",
                "Shorthair / Colorpoint",
                "Tubuh langsing dan elegan, mata berwarna biru jernih, serta pola warna colorpoint (lebih gelap di wajah, telinga, kaki, dan ekor).",
                R.drawable.siama
        ));

        listHewan.add(new Hewan(
                "British Shorthair",
                "Felis catus",
                "Shorthair / Bulu Pendek",
                "Berbadan tegap, pipi bulat menggembung (chubby), serta bulu pendek yang sangat padat dan lembut (identik dengan warna abu-abu).",
                R.drawable.british
        ));

        listHewan.add(new Hewan(
                "Sphynx",
                "Felis catus",
                "Hairless / Tanpa Bulu",
                "Memiliki tampilan unik tanpa bulu (hanya bulu sangat halus), kulit berkerut, telinga lebar, serta sifat yang sangat aktif dan ramah.",
                R.drawable.sphynx
        ));

        adapter = new HewanAdapter(this, listHewan);
        listViewHewan.setAdapter(adapter);

        searchViewHewan.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
    }
}