package com.Aisya_U_Tondu_F52124046.aplikasi_uts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class HewanAdapter extends BaseAdapter implements Filterable {
    private Context context;
    private List<Hewan> listHewanOriginal;
    private List<Hewan> listHewanFiltered;

    public HewanAdapter(Context context, List<Hewan> listHewan) {
        this.context = context;
        this.listHewanOriginal = listHewan;
        this.listHewanFiltered = listHewan;
    }

    @Override
    public int getCount() {
        return listHewanFiltered.size();
    }

    @Override
    public Object getItem(int position) {
        return listHewanFiltered.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_row_hewan, parent, false);
            holder = new ViewHolder();
            holder.imgFoto = convertView.findViewById(R.id.img_foto_hewan);
            holder.tvNama = convertView.findViewById(R.id.tv_nama_hewan);
            holder.tvNamaLatin = convertView.findViewById(R.id.tv_nama_latin);
            holder.tvKategori = convertView.findViewById(R.id.tv_kategori_hewan);
            holder.tvDeskripsi = convertView.findViewById(R.id.tv_deskripsi_hewan);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Hewan hewan = listHewanFiltered.get(position);
        holder.tvNama.setText(hewan.getNama());
        holder.tvNamaLatin.setText(hewan.getNamaLatin());
        holder.tvKategori.setText("Kategori: " + hewan.getKategori());
        holder.tvDeskripsi.setText(hewan.getDeskripsi());
        holder.imgFoto.setImageResource(hewan.getFotoResId());

        return convertView;
    }

    private static class ViewHolder {
        ImageView imgFoto;
        TextView tvNama, tvNamaLatin, tvKategori, tvDeskripsi;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                List<Hewan> filteredList = new ArrayList<>();

                if (constraint == null || constraint.length() == 0) {
                    filteredList.addAll(listHewanOriginal);
                } else {
                    String filterPattern = constraint.toString().toLowerCase().trim();
                    for (Hewan item : listHewanOriginal) {
                        if (item.getNama().toLowerCase().contains(filterPattern) ||
                                item.getKategori().toLowerCase().contains(filterPattern)) {
                            filteredList.add(item);
                        }
                    }
                }

                results.values = filteredList;
                results.count = filteredList.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                listHewanFiltered = (List<Hewan>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}